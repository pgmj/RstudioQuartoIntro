This is derived from https://codepen.io/matteobruni/pen/bGdomGq

Options are controlled using `script.js` file.
